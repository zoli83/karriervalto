console.log("JS works")

